using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;

namespace P3_22SA11A021
{
    public partial class MainWindow : Window
    {
        private TcpListener server;
        private TcpClient client;
        private StreamReader reader;
        private StreamWriter writer;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Start Server
        private async void btnStart_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("Start Server clicked!");
            try
            {
                int port = int.Parse(txtPortS.Text);
                server = new TcpListener(IPAddress.Any, port);
                server.Start();

                txtChat.Text += "Server started...\n";
                Console.WriteLine("Server started...");

                client = await server.AcceptTcpClientAsync();
                reader = new StreamReader(client.GetStream());
                writer = new StreamWriter(client.GetStream()) { AutoFlush = true };

                txtChat.Text += "Client connected!\n";
                Console.WriteLine("Client connected!");
                ListenForMessages();
            }
            catch (Exception ex)
            {
                txtChat.Text += $"Error: {ex.Message}\n";
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        // Connect Client
        private async void btnConn_Click(object sender, RoutedEventArgs e)
        {
            Console.WriteLine("Connect button clicked!");
            try
            {
                string ip = txtIPC.Text;
                int port = int.Parse(txtPortC.Text);

                client = new TcpClient();
                await client.ConnectAsync(IPAddress.Parse(ip), port);

                reader = new StreamReader(client.GetStream());
                writer = new StreamWriter(client.GetStream()) { AutoFlush = true };

                txtChat.Text += "Connected to server!\n";
                Console.WriteLine("Connected to server!");
                ListenForMessages();
            }
            catch (Exception ex)
            {
                txtChat.Text += $"Error: {ex.Message}\n";
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        // Send Message
        private async void btnSend_Click(object sender, RoutedEventArgs e)
        {
            if (writer != null && !string.IsNullOrWhiteSpace(txtPesan.Text))
            {
                Console.WriteLine($"Sending message: {txtPesan.Text}");
                await writer.WriteLineAsync(txtPesan.Text);
                txtChat.Text += $"You: {txtPesan.Text}\n";
                txtPesan.Text = "";
            }
        }

        // Listen for Incoming Messages
        private async void ListenForMessages()
        {
            try
            {
                while (client.Connected)
                {
                    string message = await reader.ReadLineAsync();
                    if (message != null)
                    {
                        txtChat.Text += $"Friend: {message}\n";
                        Console.WriteLine($"Received message: {message}");
                    }
                }
            }
            catch (Exception ex)
            {
                txtChat.Text += $"Connection closed: {ex.Message}\n";
                Console.WriteLine($"Connection closed: {ex.Message}");
            }
        }
    }
}
